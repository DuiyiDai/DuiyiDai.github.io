"""Independent educational calculation engine. No runtime network or LLM."""

__version__ = "0.1.0"
